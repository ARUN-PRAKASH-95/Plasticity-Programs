function [sig6,A66,sdvl]=vmises_perzyna(eps6,sdvl,dt,ttype)

%==========================================================================
% vmises.m (version 4)
%
% standard radial return algorithm for small strain plasticity with
% linear isotropic and kinematic hardening
%==========================================================================
% 
% coded by: B. Kiefer 19 Feb 2013
%           last modification: 19 Feb 2013
%
% comments: -> execution:
%              drive
% 
%==========================================================================
tol=1e-8;

% material parameters
matp = inputmat();
xE        = matp(1);
xnu       = matp(2);
xsigy0    = matp(3);
xH        = matp(4);
xh        = matp(5);
eta       = matp(6);
xmu  = xE/(2*(1+xnu));
xk   = xE/(3*(1-2*xnu));
%
% characteristic time
tau=eta/2/xmu;
%
% general 
ii = [1,2,3,1,2,1];
jj = [1,2,3,2,3,3];
xid = eye(3);

% restore the strain tensor
eps = [eps6(1) eps6(4)/2 eps6(6)/2;
       eps6(4)/2 eps6(2) eps6(5)/2;
       eps6(6)/2 eps6(5)/2 eps6(3)];

% restore the internal variables at tn
epspn   = [sdvl(1) sdvl(4)/2 sdvl(6)/2;
           sdvl(4)/2 sdvl(2) sdvl(5)/2;
           sdvl(6)/2 sdvl(5)/2 sdvl(3)];
Balphan = [sdvl(1+6) sdvl(4+6)/2 sdvl(6+6)/2;
           sdvl(4+6)/2 sdvl(2+6) sdvl(5+6)/2;
           sdvl(6+6)/2 sdvl(5+6)/2 sdvl(3+6)];
alphan  =  sdvl(13);
%
epsp = epspn;              % plastic strain tensor
Balpha = Balphan;          % tensorial internal variable alpha
alpha = alphan;            % scalar hardening variable alpha
%
% linear elastic behavior
deps = eps - 1/3*trace(eps)*xid;
sig=2*xmu*deps + xk*trace(eps)*xid;
C = xk*t2_otimes_t2(xid,xid) + 2*xmu*getP4sym();
%
% % TRIAL STEP
% deps = ................ deviatoric part of the strain tensor
% dsigtr = .............. deviatoric part of the trial stress tensor
% Bbetatr = ..............trial value of the back-stress tensor
% betatr = ...............trial value of the increase in yield stress (scalar beta)
% xitr = .................trial value of deviatoric stress difference
% nxitr = ................norm of xitr (use function t2_contr_t2(A,B) contained in ./tensor/ to compute);
% ntr = ..................flow direction from trial state
% %
% % trial yield function  
% phitr = ................trial value of the yield function
%
% decide if elastic or elastic-plastic step
%
% for tangent computation use the auxiliary functions (contained in ./tensor)
%     t2_otimes_t2(A,B)
%     getP4sym()
%
% restore stress tensor as vector
sig6=zeros(6,1);
for i=1:6
    sig6(i) = sig(ii(i),jj(i));
end

% restore stiffness tensor as matrix
ii = [1,2,3,1,2,1];
jj = [1,2,3,2,3,3];
A66=zeros(6,6);
%if ttype==0
    for i=1:6
        for j=1:6
        A66(i,j) = C(ii(i),jj(i),ii(j),jj(j));
        end
    end
%end

% store history variables
sdvl(1:6,1)=[epsp(1,1) epsp(2,2) epsp(3,3)...
             2*epsp(1,2) 2*epsp(2,3) 2*epsp(1,3)]';
sdvl(7:12,1)=[Balpha(1,1) Balpha(2,2) Balpha(3,3)...
             2*Balpha(1,2) 2*Balpha(2,3) 2*Balpha(1,3)]';
sdvl(13) = alpha;
end
